// config.js
const secret = 'secret-key';  //move this to a more secure location later on
module.exports = { secret };
